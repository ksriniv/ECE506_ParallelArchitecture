/************************************************************
			Course 		: 	CSC456
			Source 		:	msi.cc
			Instructor	:	Ed Gehringer
			Email Id	:	efg@ncsu.edu
------------------------------------------------------------
	© Please do not replicate this code without consulting
		the owner & instructor! Thanks!
*************************************************************/ 
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
using namespace std;
#include "main.h"
#include "cache.h"
#include "mosi.h"

void MOSI::PrRd(ulong addr, int processor_number) {
}                            

void MOSI::PrWr(ulong addr, int processor_number) {
} 


void MOSI::BusRd(ulong addr) {
} 

void MOSI::BusRdX(ulong addr) {
} 

void MOSI::BusUpgr(ulong addr) {
}

bool MOSI::writeback_needed(cache_state state) {
	//edit this function to return the correct boolean value
	return false;
}
