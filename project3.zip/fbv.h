/************************************************************
 Course		: 	CSC/ECE506
 Source 		:	fbv.h
 Owner		:	Ed Gehringer
 Email Id	:	efg@ncsu.edu
 ------------------------------------------------------------*
 � Please do not replicate this code without consulting
 the owner & instructor! Thanks!
 *************************************************************/
#include "directory.h"
class FBV: public dir_entry {
private:
	bool bit[4];
 
 public:
	unsigned long get_dir_tag()     				{ return dir_entry::tag; }
	dir_state get_state()							{ return dir_entry::state;}
	void set_dir_state(dir_state d_state)			{ dir_entry::state = d_state;}
	void set_dir_tag(unsigned long a)				{ tag = a; }
	void update_sharer_entry(int proc_num);
	void remove_sharer_entry(int proc_num);
	int check_sharer_entry(int np);
	void sendInv_sharer(ulong addr, int num_proc, int proc_num);
	void sendInt_sharer(ulong addr, int num_proc, int proc_num);
};
